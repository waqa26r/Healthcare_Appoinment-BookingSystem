$(document).ready(function () {
    $('#loginForm').validate({
        rules: {
            email: {
                required: true,
                email: true
            },
            pwd: {
                required: true,
                minlength:   8
            }
        },
        messages: {
            email: {
                required: "Please enter your email address.",
                email: "Please enter a valid email address."
            },
            pwd: {
                required: "Please provide a password.",
                minlength: "Your password must be at least   8 characters long."
            }
        },
        submitHandler: function (form) {
            // Form is valid, you can perform additional actions here if needed
            console.log("Form is valid.");
            // form.submit();
            // window.location.href = "Registration.html";
        }
    });
});

// Validation functions
function validateEmail(emailInput) {
    var re = /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z]{2,})+$/;
    return re.test(emailInput.value);
}

function validatePasswordLength(passwordInput) {
    var minLength =   8;
    return passwordInput.value.length >= minLength;
}
