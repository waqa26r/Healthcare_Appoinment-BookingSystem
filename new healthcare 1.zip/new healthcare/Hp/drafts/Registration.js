
// Function to check if the entered email is valid

function  nameIsValid(nameInput) {
    var re = /^[a-zA-Z]+$/;
    return re.test(nameInput.value);
}

function  emailIsValid(emailInput) {
    var re = /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z]{2,})+$/;
    return re.test(emailInput.value);
}

function validateEmail(emailInput) {
    var re = /\S+@\S+\.\S+/;
    return re.test(emailInput.value);
  }
  

  function validatePasswordLength(passwordInput) {
    var minLength =  8;
    return passwordInput.value.length >= minLength;
  }
  
  // Function to check if the password fields match
  function passwordsMatch(passwordInput, confirmPasswordInput) {

    return passwordInput.value === confirmPasswordInput.value;
  }
  
  // Function to check if the age is within a valid range
  function isAgeValid(ageInput) {
    return ageInput.value >=  18 && ageInput.value <=  120;
  }
  
  // Function to check if the contact number is valid
  function isContactNumberValid(contactNumberInput) {
    var re = /^\d{10}$/;
    return re.test(contactNumberInput.value);
  }
  
  // Function to check if the checkbox is checked
  function isCheckboxChecked(checkbox) {
    return checkbox.checked;
  }
  
  function enableFields() {
    document.getElementById("age").disabled = false;
    document.getElementById("bloodGroup").disabled = false;
    document.getElementById("gender").disabled = false;
    document.getElementById("address").disabled = false;
}

function disableFields() {
    document.getElementById("age").disabled = true;
    document.getElementById("bloodGroup").disabled = true;
    document.getElementById("gender").disabled = true;
    document.getElementById("address").disabled = true;
}


  // Function to handle form submission
  function handleSubmit(event) {
    // Prevent the form from submitting by default
    event.preventDefault();
  
    // Get the relevant input elements
    var nameInput = document.querySelector('#name');
    var emailInput = document.querySelector('#email');
    var passwordInput = document.querySelector('#password');
    var confirmPasswordInput = document.querySelector('#confirmPassword');
    var ageInput = document.querySelector('#age');
    var contactNumberInput = document.querySelector('#phoneNumber');
    var checkbox = document.querySelector('.policy input[type="checkbox"]');
  
    // Perform validation

    if (!nameIsValid(nameInput)) {
      alert('Please enter a valid name.');
      return false;
    }

    else if (!validateEmail(emailInput)) {
      alert('Please enter a valid email address.');
      return false;
    } 
    
    else if (!validatePasswordLength(passwordInput)) {
      alert('Please enter a atleast 8 character password.');
      return false;
    }
      
    else if (!passwordsMatch(passwordInput, confirmPasswordInput)) {
      alert('Passwords do not match. Please try again.');
      return false;
    } 
    else if (!isAgeValid(ageInput)) {
      alert('Please enter a valid age between  18 and  120.');
      return false;
    } else if (!isContactNumberValid(contactNumberInput)) {
      alert('Contact number should be exactly  10 digits long.');
      console.error('Please enter a valid contact number');
         
    } else if (!isCheckboxChecked(checkbox)) {
      alert('You must accept the terms and conditions to register.');
      return false;
    } else {
      // If everything is valid, you could continue with form submission
      console.log("Form is valid.");
      // You can comment out the line below if you don't want to actually submit the form
      // event.target.submit();
      return true;
    }



  }
  
  // Attach the submit handler to the form
  document.querySelector('form').addEventListener('submit', handleSubmit);

  document.getElementById("registrationForm").addEventListener("submit", function(event) {
    event.preventDefault();

    // Check if any role is selected
    var roleIsSelected = Array.from(document.getElementsByName('role')).some(function(element) {
        return element.checked;


        var minPasswordLength =  8;
        if (password.length < minPasswordLength) {
            alert("Your password must be at least " + minPasswordLength + " characters long.");
            return;
        }
    
    });

    if (!roleIsSelected) {
        alert("Please select a role.");
        return;
        
    }});
    
  